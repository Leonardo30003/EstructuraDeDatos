/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.estructuradedatos;

import java.time.Clock;
import java.util.Scanner;

/**
 *
 * @author leona
 */
public class EstructuraDeDatos {

    public static void main(String[] args) {
        //arreglos(args);
        busquedaReemplazo();
    }
    public static void busquedaReemplazo() {
        String nombres[]={"yeferson","artellete","Leonardo","juan","kevin",
            "danny","ricardo","nicolas","santiago","andres","anderson"};
        Scanner scanner = new Scanner(System.in);
        System.out.println("por favor ingrese el nombre a buscar");
        String dato =scanner.nextLine();
        for (int i=0; i < nombres.length; i++){
            if(nombres[i].equals(dato)){
                System.err.println("Se encontro el nombre");
                System.out.println(" deseas remplazar el nombre y/n");
                String reemplazar=scanner.nextLine();
                if (reemplazar.equals("y")){
                    System.out.println("pir favor ingrese el valor a reemplazar");
                    String valor = scanner.nextLine();
                    nombres[i]=valor;
                }else{
                    System.out.println("usted decidio no remplazar");
            }}
        }
    }
    public static void arreglos (String[] args) {
        String nombres[] = new String [11];
        nombres[0]= "yeferson";
        nombres[1]="arlette";
        nombres[2]= "Leonardo";
        nombres[3]="Juan";
        nombres[4]= "kevin";
        nombres[5]="Danny";
        nombres[6]= "Ricardo";
        nombres[7]="Nicolas";
        nombres[8]= "Santiago";
        nombres[9]="Andres";
        nombres[10]= "Anderson";
        
        for ( int i =0; i < nombres.length; i++){
            System.out.println(nombres[i]);
        }
        for (int j = nombres.length-1; j>=0;j--);{
        System.out.println(nombres[j]);
    }
}
}